This is my snipet :)
